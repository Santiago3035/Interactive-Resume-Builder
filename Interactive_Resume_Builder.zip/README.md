# Interactive Resume Builder

## Опис
Вебдодаток для створення професійного резюме з кастомізацією та експортом у PDF.

## Функціонал
- 📌 Основна функція 1
- 📌 Основна функція 2
- 📌 Основна функція 3

## Встановлення
1. Клонуйте репозиторій:
   ```sh
   git clone https://github.com/your-username/Interactive_Resume_Builder.git
   ```
2. Перейдіть у директорію проєкту:
   ```sh
   cd Interactive_Resume_Builder
   ```
3. Встановіть залежності (якщо є):
   ```sh
   npm install
   ```
4. Запустіть застосунок:
   ```sh
   npm start
   ```

## Ліцензія
Цей проєкт ліцензований під MIT License.
